package main

import (
	"os"
	"fmt"
	"net"
	"log"
	"time"
//	"./libs"
)

const (
	CONN_HOST = ""
	CONN_PORT = "2010"
	CONN_TYPE = "tcp"
)

func main() {
    l, err := net.Listen(CONN_TYPE, CONN_HOST + ":" + CONN_PORT)
    if err != nil {
        fmt.Println("Error listening:", err.Error())
        os.Exit(1)
    }
    defer l.Close()
    fmt.Println("Listening on " + CONN_HOST + ":" + CONN_PORT)
    for {
        conn, err := l.Accept()
        if err != nil {
            fmt.Println("Error accepting: ", err.Error())
            os.Exit(1)
        }
		log.Printf("device connected.\n")
		go handleRequest(conn)
    }
}

func handler_packet(buf []byte, conn net.Conn) {
	data_str := string(buf[:])
	var data_hexstr string = fmt.Sprintf("%X", data_str)
	log.Printf(data_hexstr)
}

func handleRequest(conn net.Conn) {
	for {
		//超過60秒斷線
		timeoutDuration := 60 * time.Second
		conn.SetReadDeadline(time.Now().Add(timeoutDuration))
		
		buf := make([]byte, 1024)
		_, err := conn.Read(buf)
		if err != nil {
			conn.Close()
			log.Printf("device disconnected")
			break;
		}
		go handler_packet(buf, conn)
	}
}