package libs

import (
	"fmt"
	//"time"
	"encoding/hex"
	"strconv"
)

func DoubleHexstrToHexstr (data_str string) string {
	//把雙符號合併成單符號 [F0 C0 F0 A0] = [FCFA]
	data_hexstr_origin := fmt.Sprintf("%X", data_str)
	var data_hexstr string = ""
	for i:=0; i<len(data_hexstr_origin); i++ {
		if i %2 != 0 {
			data_hexstr = data_hexstr + string(data_hexstr_origin[i])
		}
	}
	return data_hexstr
}
func P4_TO_HEXSTR (pass4 int32) string {
	return fmt.Sprintf("%04X", pass4)
}
func UXT_TO_HEXSTR (ux_t int32) string {
	//把UNIX_TIMESTAMP轉成HEX LEN8 [FF FF FF FF]
	return fmt.Sprintf("%08X", ux_t)
}
func HEXSTR_TO_BYTE (hexstr string) []byte {
	//HEX STRING 轉 []byte
	bs,_ := hex.DecodeString(hexstr)
	return bs
}
func HEXSTR_TO_INT32 (hexstr string) int32 {
	n, err := strconv.ParseUint(hexstr, 16, 32)
	if err != nil {
		panic(err)
	}
	return int32(n)
}
/*
func TSTimeToHexStr (ts_t string) {
	tm2, _ := time.Parse("2006-01-02 15:04:05", ts_t)
	fmt.Println(tm2)
	//return UXTimeToHexStr(tm2)
}
*/