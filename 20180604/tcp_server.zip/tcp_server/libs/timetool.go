package libs

import (
	"fmt"
	"time"
)

func TST_TO_UXT (ts_t string) int32 {
	//yyyy-mm-dd hh:ii:ss 轉 UNIX_TIMESTAMP
	tm, _ := time.Parse("2006-01-02 15:04:05", ts_t)
	return int32(tm.Unix())
}

func UXT_TO_TXT (ux_t int32) string {
	tm := time.Unix(int64(ux_t), 0)
	return tm.Format("2006-01-02 15:04:05")
}

func UXT_NOW () int32 {
	//NOW UNIX_TIMESTAMP
	return int32(time.Now().Unix())
}

func TSD_TODAY () string {
	tm := time.Unix(time.Now().Unix(), 0)
	return tm.Format("2006-01-02")
}

func UXT_YEAR_ZERO () int32 {
	//今年的零點UNIX_TIMESTAMP
	year  := time.Now().Year()
	ts_t  := fmt.Sprintf("%d-01-01 00:00:00", year)
	tm, _ := time.Parse("2006-01-02 15:04:05", ts_t)
	return int32(tm.Unix())
}