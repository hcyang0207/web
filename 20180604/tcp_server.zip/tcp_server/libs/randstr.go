package libs

import (
	"math/rand"
)

func Randstr(len_t int) string {
	//產生隨機字串
	letters := []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_")
	b := make([]rune, len_t)
	for i := range b {
		b[i] = letters[rand.Intn(len(letters))]
	}
	return string(b)
}