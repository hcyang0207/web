package main

import (
	"io/ioutil"
	"os"
	"fmt"
	"net"
	"log"
	"time"
	"./libs"
)

const (
	CONN_HOST = ""
	CONN_PORT = "2010"
	CONN_TYPE = "tcp"
)

func main() {
    l, err := net.Listen(CONN_TYPE, CONN_HOST + ":" + CONN_PORT)
    if err != nil {
        fmt.Println("Error listening:", err.Error())
        os.Exit(1)
    }
    defer l.Close()
    fmt.Println("Listening on " + CONN_HOST + ":" + CONN_PORT)
    for {
        conn, err := l.Accept()
        if err != nil {
            fmt.Println("Error accepting: ", err.Error())
            os.Exit(1)
        }
		log.Printf("device connected.\n")
		go handleRequest(conn)
    }
}

func handler_packet(buf []byte, conn net.Conn) {
	data_str := string(buf[:])
	var data_hexstr string = fmt.Sprintf("%X", data_str)	//原始package
	head_1 := data_hexstr[0:8]								//header#1
	head_2 := data_hexstr[20:28]							//header#2
	
	if(head_1 == "F0FCFFFF" && head_2 == "FFFFFFFF"){		//判斷header
		uuid := data_hexstr[8:20]							//取得UUID
		vcnt := libs.HEXSTR_TO_INT32(data_hexstr[28:30])	//取得VCNT
		log.Printf("revice [%s] [%d]\n", uuid, vcnt)
		
		//分析原始數值
		var file_tmp_str string
		data := data_hexstr[30:2000]						//原始資料(長度985)
		for i:=0; i<985; i++ {
			pi := libs.HEXSTR_TO_INT32(data[i*2:i*2+2])
			str := fmt.Sprintf("%d = %d\r\n", i, pi)
			file_tmp_str += str
			//log.Printf("[%d] = [%d]\n", i, pi)
		}
		arr := []byte(file_tmp_str)
		file_name := fmt.Sprintf("./tmp/%s_%d_output.txt", uuid, vcnt)
		ioutil.WriteFile(file_name, arr, 0644)
	} else {
		log.Printf("wrong\n")
	}
}

func handleRequest(conn net.Conn) {
	for {
		//超過5秒斷線
		timeoutDuration := 60 * time.Second
		conn.SetReadDeadline(time.Now().Add(timeoutDuration))
		
		buf := make([]byte, 1000)
		_, err := conn.Read(buf)
		if err != nil {
			conn.Close()
			log.Printf("device disconnected")
			break;
		}
		go handler_packet(buf, conn)
	}
}