package libs

import (
	"fmt"
	"encoding/hex"
	"strconv"
)

func UXT_TO_HEXSTR (ux_t int32) string {
	//把UNIX_TIMESTAMP轉成HEX LEN8 [FF FF FF FF]
	return fmt.Sprintf("%08X", ux_t)
}
func HEXSTR_TO_BYTE (hexstr string) []byte {
	//HEX STRING 轉 []byte
	bs,_ := hex.DecodeString(hexstr)
	return bs
}
func HEXSTR_TO_INT32 (hexstr string) int32 {
	n, err := strconv.ParseUint(hexstr, 16, 32)
	if err != nil {
		panic(err)
	}
	return int32(n)
}