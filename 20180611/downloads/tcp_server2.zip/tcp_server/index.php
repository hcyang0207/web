<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
		<meta http-equiv="Cache-Control" content="no-cache"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
		<meta name="robots" content="index, follow"/>
		<title>存取次數統計</title>
		<!-- cdn javascript and css -->
		<script src="//code.jquery.com/jquery-3.1.1.min.js" type="text/javascript"></script>
		<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" rel="stylesheet">
	</head>
	<body>
		<style>
		table tr td{
			padding:5px;
		}
		</style>
		<table border="1" width="500" align="center" style="margin: 10px auto auto;font-size:12px;">
		<tr>
			<td>UUID</td>
			<td>資料次數1 = 985</td>
		</tr>
		<?php
		$directory = "./data";
		$jsons = glob($directory . "/*.json");
		foreach(@$jsons as $obj){
			$string = file_get_contents($obj);
			$json_a = json_decode($string, true);
			$uuid = preg_replace("/^\.\/data\/(.*)\.json$/", "$1", $obj);
			echo "
			<tr>
				<td>{$uuid}</td>
				<td>{$json_a["count"]}</td>
			</tr>
			";
		}
		?>
		</table>
	</body>
</html>