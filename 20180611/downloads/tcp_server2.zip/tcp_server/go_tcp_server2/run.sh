cd /var/www/html/tcp_server/go_tcp_server2
killall go_tcp_server2 -q
filename=$(date +%Y%m%d)
sudo go build
nohup ./go_tcp_server2 >> ./log/$filename.log 2>&1&
