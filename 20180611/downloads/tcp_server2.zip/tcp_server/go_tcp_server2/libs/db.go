package libs

import (
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
	"log"
	"fmt"
)

func UP_DEVICE_ONLINE(uuid string) {
	//更新在線裝置
	s := fmt.Sprintf("UPDATE `devices` SET `online` = UNIX_TIMESTAMP(), `updated_at` = UNIX_TIMESTAMP() WHERE `uuid` = '%v'", uuid)
	//log.Println(s)
	DB_query(s)
}

func DB_select(s string, op func(*sql.Rows)) {
	db, err := sql.Open("mysql", "root:password@tcp(localhost)/dbname")
	if err != nil {
		log.Println("Open database error: %s\n", err)
	}
	err = db.Ping()
	if err != nil {
		log.Println(err)
	}
	defer db.Close()
	rows, err := db.Query(s)
	if err != nil {
		log.Println(err)
	}
	op(rows)
	rows.Close()
}

func DB_query(s string) {
	db, err := sql.Open("mysql", "root:password@tcp(localhost)/dbname")
	if err != nil {
		log.Println("Open database error: %s\n", err)
	}
	err = db.Ping()
	if err != nil {
		log.Println(err)
	}
	defer db.Close()
	_, exec_err := db.Exec(s)
	if exec_err != nil {
		log.Println(exec_err)
	}
}