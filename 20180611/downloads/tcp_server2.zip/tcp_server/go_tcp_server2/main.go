package main

import (
	"io/ioutil"
	"os"
	"fmt"
	"net"
	"log"
	"time"
	"./libs"
	"regexp"
	"encoding/json"
//	"strconv"
)

const (
	CONN_HOST = ""
	CONN_PORT = "12345"
	CONN_TYPE = "tcp"
)

func main() {
    l, err := net.Listen(CONN_TYPE, CONN_HOST + ":" + CONN_PORT)
    if err != nil {
        fmt.Println("Error listening:", err.Error())
        os.Exit(1)
    }
    defer l.Close()
	
	go handle_data()
	
    fmt.Println("Listening on " + CONN_HOST + ":" + CONN_PORT)
    for {
        conn, err := l.Accept()
        if err != nil {
            fmt.Println("Error accepting: ", err.Error())
            os.Exit(1)
        }
		log.Printf("device connected.\n")
		go handleRequest(conn)
    }
	
	
}

func handle_data() {
	for{
		files, err := ioutil.ReadDir("../cache/")
		if err != nil {
			log.Fatal(err)
		}
		for _, f := range files {
			reStr := regexp.MustCompile("^(.*)_(.*)_(.*)$")
			output := reStr.ReplaceAllString(f.Name(), "$1")
			write_count(output)
			os.Remove("../cache/" + f.Name())
		}
		time.Sleep(1 * time.Second)
	}
}

func write_count(uuid string) {
	file_path := "../data/" + uuid + ".json"
	if _, err := os.Stat(file_path); os.IsNotExist(err) {
		count_map := map[string]int{"count": 0}
		map_count, _ := json.Marshal(count_map)
		//fmt.Println(string(map_count))
		ioutil.WriteFile(file_path, []byte(map_count), 0644)
	} else {
		//抓取上次
		raw, err := ioutil.ReadFile(file_path)
		if err != nil {
			fmt.Println(err.Error())
			os.Exit(1)
		}
		var c map[string]int
		json.Unmarshal(raw, &c)
		//增加1
		count_map := map[string]int{"count": c["count"] + 1}
		map_count, _ := json.Marshal(count_map)
		fmt.Println(string(map_count))
		ioutil.WriteFile(file_path, []byte(map_count), 0644)
	}
}

func handler_packet(buf []byte, conn net.Conn) {
	data_str := string(buf[:])
	var data_hexstr string = fmt.Sprintf("%X", data_str)	//原始package
	head_1 := data_hexstr[0:8]								//header#1
	head_2 := data_hexstr[20:28]							//header#2
	
	if(head_1 == "F0FCFFFF" && head_2 == "FFFFFFFF"){		//判斷header
		uuid := data_hexstr[8:20]							//取得UUID
		vcnt := libs.HEXSTR_TO_INT32(data_hexstr[28:30])	//取得VCNT
		log.Printf("revice [%s] [%d]\n", uuid, vcnt)
		
		//分析原始數值
		var file_tmp_str string
		data := data_hexstr[30:2000]						//原始資料(長度985[0-984])
		for i:=0; i<985; i++ {
			pi := libs.HEXSTR_TO_INT32(data[i*2:i*2+2])
			str := fmt.Sprintf("%d = %d\r\n", i, pi)
			file_tmp_str += str
			//log.Printf("[%d] = [%d]\n", i, pi)
		}
		arr := []byte(file_tmp_str)
		file_name := fmt.Sprintf("../cache/%s_%d_output.txt", uuid, vcnt)
		ioutil.WriteFile(file_name, arr, 0644)
		//寫入count
		
	} else {
		log.Printf("wrong\n")
	}
}

func handleRequest(conn net.Conn) {
	for {
		//超過60秒斷線
		timeoutDuration := 60 * time.Second
		conn.SetReadDeadline(time.Now().Add(timeoutDuration))
		
		buf := make([]byte, 1000)
		_, err := conn.Read(buf)
		if err != nil {
			conn.Close()
			log.Printf("device disconnected")
			break;
		}
		go handler_packet(buf, conn)
	}
}